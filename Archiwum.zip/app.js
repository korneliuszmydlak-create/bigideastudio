/* Big Idea Studio — jeden plik, jedenaście zadań. Kolejność ma znaczenie.
   Cały ruch jest wyłączany jednym warunkiem: prefers-reduced-motion. */

(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hasIO = 'IntersectionObserver' in window;

  // Znacznik działającego skryptu — CSS ukrywa stany początkowe animacji tylko pod nim,
  // więc bez JS portret, znak w kontakcie i listy stoją w całości.
  document.documentElement.classList.add('js');
  window.bisApp = true;   // wyłącza bezpiecznik z <head>

  var clamp01 = function (v) { return v < 0 ? 0 : v > 1 ? 1 : v; };
  var maRaf = 'requestAnimationFrame' in window;

  /* Wspólna klatka przewijania. Moduł zgłasza dwie funkcje: czytaj (tylko pomiary)
     i pisz (tylko zapisy). W każdej klatce najpierw idą wszystkie pomiary, potem wszystkie
     zapisy — jedno przeliczenie stylu i układu zamiast kilku. Wcześniej każdy moduł miał
     własne requestAnimationFrame i mierzył stronę tuż po zapisach poprzedniego, więc
     przeglądarka liczyła wszystko 2–3 razy na klatkę i na telefonie ruch gubił klatki.
     pisz zwraca true, gdy moduł chce kolejnej klatki (wygładzanie koloru, odsłanianie słów). */
  var zadania = [], ramka = 0, tRamki = 0;

  var klatkaWspolna = function (teraz) {
    ramka = 0;
    var dt = tRamki ? Math.min(64, teraz - tRamki) : 16;
    tRamki = teraz;
    var odczyty = zadania.map(function (z) { return z.czytaj ? z.czytaj() : null; });
    var dalej = false;
    zadania.forEach(function (z, i) { if (z.pisz(odczyty[i], dt)) dalej = true; });
    if (dalej) ramka = window.requestAnimationFrame(klatkaWspolna);
    else tRamki = 0;
  };

  var budz = function () {
    if (!ramka && maRaf) ramka = window.requestAnimationFrame(klatkaWspolna);
  };

  var dodajZadanie = function (z) { zadania.push(z); budz(); };

  if (maRaf) window.addEventListener('scroll', budz, { passive: true });

  /* Wysokość ekranu do obliczeń ruchu. Na telefonie pasek adresu chowa się i wraca
     w trakcie przewijania, a innerHeight skacze wtedy o 50–110 px. Wszystkie efekty
     liczone od wysokości ekranu skakały razem z nim. Na ekranie dotykowym taką zmianę
     pomijamy — liczy się dopiero obrót, zmiana szerokości albo duża różnica wysokości. */
  var dotyk = window.matchMedia('(pointer: coarse)').matches;
  // Na dotyku wysokość bloku początkowego (clientHeight) — nie zmienia się razem z paskiem adresu.
  var zmierzEkran = function () {
    return (dotyk ? document.documentElement.clientHeight : window.innerHeight) || window.innerHeight || 1;
  };
  var vhStala = zmierzEkran(), vwStala = window.innerWidth;
  var wysokosc = function () { return vhStala; };
  var poZmianie = [];   // moduły, które po prawdziwej zmianie rozmiaru muszą przeliczyć pomiary

  window.addEventListener('resize', function () {
    var w = window.innerWidth, hh = zmierzEkran();
    if (dotyk && w === vwStala && Math.abs(hh - vhStala) < 160) return;
    vwStala = w; vhStala = hh;
    poZmianie.forEach(function (f) { f(); });
    budz();
  });

  /* Wspólny obserwator: element wchodzi na ekran raz i zostaje odsłonięty.
     Margines -12% od dołu opóźnia start do momentu, w którym element jest już widoczny,
     a nie dopiero dotknął krawędzi. */
  function reveal(nodes) {
    if (!nodes.length) return;

    if (reduced || !hasIO) {
      nodes.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -12% 0px', threshold: 0.05 });

    nodes.forEach(function (el) { io.observe(el); });
  }

  /* 1. Nagłówki na maskę: każda linia dostaje własną ramkę z ukryciem przepełnienia
     i wjeżdża spod jej krawędzi. Podział idzie po <br>, więc łamanie zostaje w markupie.
     Przy wyłączonym ruchu nie ruszamy struktury w ogóle — tekst zostaje, jak był. */
  var masked = [].slice.call(document.querySelectorAll('[data-mask]'));

  if (masked.length && !reduced) {
    masked.forEach(function (el) {
      var lines = el.innerHTML.split(/<br\s*\/?>/i);
      el.innerHTML = lines.map(function (line, i) {
        return '<span class="mask" style="--d:' + (i * 110) + 'ms"><i>' + line + '</i></span>';
      }).join('');
    });
    reveal(masked);
  }

  /* 2. Odsłanianie treści. Kaskada liczona w obrębie sekcji, nie całej strony —
     inaczej ostatnie elementy czekałyby sekundę na swoją kolej. */
  var revealables = [].slice.call(document.querySelectorAll('[data-reveal]'));

  revealables.forEach(function (el) {
    // Opis w sekcji Obszary liczy kaskadę sam dla siebie — inaczej piąty czekałby pół sekundy.
    var section = el.closest('[data-reveal-scope], section');
    if (!section) return;
    var peers = section.hasAttribute('data-reveal-scope')
      ? [section]
      : [].slice.call(section.querySelectorAll('[data-reveal]'));
    el.style.transitionDelay = Math.min(peers.indexOf(el), 5) * 90 + 'ms';
  });

  reveal(revealables);

  /* 2a. Listy wierszy (Dla kogo): kaskada liczona w obrębie listy.
     Uzbrajamy dopiero tutaj — bez skryptu lista stoi w całości.
     [data-anim]: elementy z własną animacją CSS (portret, znak w kontakcie). */
  var rows = [].slice.call(document.querySelectorAll('[data-rows]'));
  rows.forEach(function (list) {
    [].slice.call(list.children).forEach(function (li, i) { li.style.setProperty('--i', i); });
    list.classList.add('is-armed');
  });
  reveal(rows);
  reveal([].slice.call(document.querySelectorAll('[data-anim]')));

  /* 3. Schemat kół: wchodzą od środka układu na zewnątrz, bo growth management
     jest tu punktem wyjścia, a nie jedną z pięciu pozycji. */
  var kola = document.querySelector('[data-kola]');

  if (kola) {
    /* Opóźnienie liczone od odległości na ekranie, nie od pozycji w kodzie:
       hub jest pierwszy w kodzie, ale stoi w środku układu. Koła w tej samej
       odległości od huba (pary po bokach, para na dole) wchodzą razem. */
    var items = [].slice.call(kola.children);
    var hubEl = kola.querySelector('.is-hub') || items[0];
    var center = function (el) {
      var r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width || 1 };
    };
    var hc = center(hubEl);
    var rings = items.map(function (li) {
      var c = center(li);
      return Math.round(Math.hypot(c.x - hc.x, c.y - hc.y) / (hc.w * .25));
    });
    var steps = rings.filter(function (v, i) { return rings.indexOf(v) === i; })
      .sort(function (a, b) { return a - b; });
    items.forEach(function (li, i) {
      var c = center(li);
      li.style.setProperty('--d', steps.indexOf(rings[i]) * 90 + 'ms');
      // start: 45% dalej od huba niż pozycja docelowa — koła zjeżdżają się do środka
      li.style.setProperty('--tx', ((c.x - hc.x) * .45).toFixed(1) + 'px');
      li.style.setProperty('--ty', ((c.y - hc.y) * .45).toFixed(1) + 'px');
    });
    reveal([kola]);
  }

  /* 4. Zakres usług: akordeon od 760 px. Nagłówki <h3> dostają przycisk z aria-expanded,
     pierwszy opis otwarty, pozostałe zwinięte; otwartych może być kilka naraz.
     Przycisk powstaje tu, nie w markupie: bez skryptu i poniżej 760 px nagłówek jest zwykłym
     nagłówkiem, a wszystkie opisy stoją rozwinięte — nie ma przycisku, który nic nie robi.
     Zwinięty opis ma visibility:hidden (CSS), więc znika też z kolejności tabulacji i dla czytnika. */
  var obszary = document.querySelector('[data-obszary]');

  if (obszary) {
    var mqAkordeon = window.matchMedia('(min-width: 760px)');
    var pozycje = [].slice.call(obszary.querySelectorAll('.obszar')).map(function (art, i) {
      var nag = art.querySelector('.obszar-naglowek');
      var tresc = art.querySelector('.obszar-tresc');
      return nag && tresc ? { art: art, nag: nag, tresc: tresc, tekst: nag.innerHTML, otwarty: i === 0, btn: null } : null;
    }).filter(Boolean);

    var ustawPozycje = function (poz) {
      poz.btn.setAttribute('aria-expanded', poz.otwarty ? 'true' : 'false');
      poz.art.classList.toggle('is-otwarty', poz.otwarty);
    };

    var trybAkordeonu = function () {
      var akordeon = mqAkordeon.matches;
      obszary.classList.toggle('is-akordeon', akordeon);
      pozycje.forEach(function (poz) {
        if (akordeon && !poz.btn) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'obszar-przycisk';
          btn.setAttribute('aria-controls', poz.tresc.id);
          btn.innerHTML = '<span class="obszar-nazwa">' + poz.tekst + '</span><span class="obszar-znak" aria-hidden="true"></span>';
          btn.addEventListener('click', function () {
            poz.otwarty = !poz.otwarty;
            ustawPozycje(poz);
          });
          poz.nag.innerHTML = '';
          poz.nag.appendChild(btn);
          poz.btn = btn;
          ustawPozycje(poz);
        } else if (!akordeon && poz.btn) {
          poz.nag.innerHTML = poz.tekst;
          poz.btn = null;
          poz.art.classList.remove('is-otwarty');
        }
      });
    };

    trybAkordeonu();
    if (mqAkordeon.addEventListener) mqAkordeon.addEventListener('change', trybAkordeonu);
    else if (mqAkordeon.addListener) mqAkordeon.addListener(trybAkordeonu);
  }

  /* 5. Scena: wspólne tło planszy, współpracy i kontaktu, mieszane ze scrollem.
     Trzy warstwy płynności:
     a) Czysty ton jest w trzech punktach: plansza — gdy wypełnia ekran (do tego momentu
        stoi w oryginalnej Ultra z białym tekstem), grafit — w środku sceny, Ultra — gdy góra kontaktu jest na 20% wysokości ekranu
        (od tego miejsca do końca strony kontakt stoi w oryginalnej Ultra z bielą).
     b) Mieszanie w OKLab, liniowo: równy kawałek przewinięcia = równa, widoczna zmiana barwy.
     c) Wygładzanie w czasie. Kółko myszy przesuwa stronę skokami po ~100 px — gdyby kolor
        szedł wprost za pozycją, każdy „ząbek” dawałby skok barwy. Kolor goni pozycję
        z opóźnieniem ~0,25 s, więc między ząbkami przechodzi przez wszystkie odcienie pośrednie.
     Zmiana koloru nie jest ruchem na ekranie, więc działa także przy ograniczonym ruchu.
     Kolory pochodzą z tokenów w :root — zmiana palety w CSS zmienia też scenę. */
  var scena = document.querySelector('[data-scena]');

  if (scena) {
    var tony = [].slice.call(scena.querySelectorAll('[data-ton]'));

    if (tony.length > 1) {
      scena.setAttribute('data-ton-now', tony[0].getAttribute('data-ton'));
      scena.classList.add('is-live');

      if (!('requestAnimationFrame' in window)) {
        if (hasIO) {
          var tonIO = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting) scena.setAttribute('data-ton-now', entry.target.getAttribute('data-ton'));
            });
          }, { rootMargin: '-50% 0px -50% 0px', threshold: 0 });
          tony.forEach(function (el) { tonIO.observe(el); });
        }
      } else {
        var rootCS = getComputedStyle(document.documentElement);
        var hex = function (name) {
          var h = rootCS.getPropertyValue(name).trim().replace('#', '');
          return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
        };

        // sRGB (0–255) ⇄ OKLab — wzory Björna Ottossona
        var toLin = function (c) { c /= 255; return c <= .04045 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4); };
        var fromLin = function (c) {
          c = c <= .0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - .055;
          return Math.max(0, Math.min(255, c * 255));
        };
        var toLab = function (rgb) {
          var r = toLin(rgb[0]), g = toLin(rgb[1]), b = toLin(rgb[2]);
          var l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
          var m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
          var s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
          return [.2104542553 * l + .7936177850 * m - .0040720468 * s,
                  1.9779984951 * l - 2.4285922050 * m + .4505937099 * s,
                  .0259040371 * l + .7827717662 * m - .8086757660 * s];
        };
        var toRGB = function (lab) {
          var l = lab[0] + .3963377774 * lab[1] + .2158037573 * lab[2];
          var m = lab[0] - .1055613458 * lab[1] - .0638541728 * lab[2];
          var s = lab[0] - .0894841775 * lab[1] - 1.2914855480 * lab[2];
          l = l * l * l; m = m * m * m; s = s * s * s;
          return [fromLin(4.0767416621 * l - 3.3077115913 * m + .2309699292 * s),
                  fromLin(-1.2684380046 * l + 2.6097574011 * m - .3413193965 * s),
                  fromLin(-.0041960863 * l - .7034186147 * m + 1.7076147010 * s)];
        };

        var ultra = toLab(hex('--bis-accent')), ink = toLab(hex('--bis-ink'));
        var lt = toLab(hex('--bis-accent-lt')), white = toLab([255, 255, 255]);

        // każdy ton: tło, tekst, tekst drugorzędny (+ krycie), linia (+ krycie)
        var PALETA = {
          ultra: { bg: ultra, fg: white, fg2a: .78, rulea: .28 },
          ink:   { bg: ink,   fg: lt,    fg2a: 1,   rulea: .28 }
        };

        var lerp = function (a, b, t) { return a + (b - a) * t; };
        var mix3 = function (a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; };
        var css = function (lab, a) {
          var c = toRGB(lab);
          return 'rgba(' + c[0].toFixed(1) + ',' + c[1].toFixed(1) + ',' + c[2].toFixed(1) + ',' + a.toFixed(3) + ')';
        };

        // Punkty czystego tonu w pikselach dokumentu. Liczone przy starcie i zmianie rozmiaru,
        // nie w każdej klatce — przewijanie nie zmienia układu.
        var punkty = [];
        var zmierz = function () {
          var vh = wysokosc(), sy = window.pageYOffset;
          var maxY = document.documentElement.scrollHeight - vh;
          punkty = tony.map(function (el, i) {
            var r = el.getBoundingClientRect(), top = r.top + sy, y;
            if (i === 0) y = top;                                 // plansza wypełnia ekran — czysta Ultra z bielą
            else if (i === tony.length - 1) y = Math.min(top - vh * .2, maxY);  // kontakt: czysta Ultra, zanim nagłówek dojdzie do góry ekranu
            else y = top + r.height / 2 - vh / 2;
            return { y: y, ton: PALETA[el.getAttribute('data-ton')] };
          });
          // Sekcje środkowe: punkt w pół drogi między „środek na środku ekranu” a środkiem
          // całej sceny — obie połowy przejścia mają podobną długość, więc żadna nie jest stroma.
          var y0 = punkty[0].y, yN = punkty[punkty.length - 1].y;
          for (var m = 1; m < punkty.length - 1; m++) {
            punkty[m].y = (punkty[m].y + (y0 + (yN - y0) * m / (punkty.length - 1))) / 2;
          }
          for (var k = 1; k < punkty.length; k++) {          // punkty muszą rosnąć
            if (punkty[k].y <= punkty[k - 1].y) punkty[k].y = punkty[k - 1].y + 1;
          }
        };

        var TAU = 250;            // ms — stała wygładzania; większa = łagodniej, ale z większym opóźnieniem
        var yPokaz = window.pageYOffset;
        var ostatniKolor = '';    // zapis tylko przy zmianie — daleko od sceny kolor stoi i nic nie liczymy

        var maluj = function (y) {
          var a = punkty[0], b = punkty[0], t = 0;

          if (y >= punkty[punkty.length - 1].y) {
            a = b = punkty[punkty.length - 1];
          } else if (y > punkty[0].y) {
            for (var i = 0; i < punkty.length - 1; i++) {
              if (y < punkty[i + 1].y) {
                a = punkty[i]; b = punkty[i + 1];
                t = (y - a.y) / (b.y - a.y);
                break;
              }
            }
          }

          var klucz = a.y + '|' + b.y + '|' + t.toFixed(4);
          if (klucz === ostatniKolor) return;
          ostatniKolor = klucz;
          var fg = mix3(a.ton.fg, b.ton.fg, t);
          var s = scena.style;
          s.setProperty('--bg', css(mix3(a.ton.bg, b.ton.bg, t), 1));
          s.setProperty('--fg', css(fg, 1));
          s.setProperty('--accent', css(fg, 1));
          s.setProperty('--fg-2', css(fg, lerp(a.ton.fg2a, b.ton.fg2a, t)));
          s.setProperty('--rule', css(fg, lerp(a.ton.rulea, b.ton.rulea, t)));
        };

        // Kolor goni pozycję tylko, dopóki jej nie dogoni — potem klatki stają i nie zjadają baterii.
        var przelicz = function () { zmierz(); ostatniKolor = ''; maluj(yPokaz); budz(); };

        zmierz();
        maluj(yPokaz);
        dodajZadanie({
          czytaj: function () { return window.pageYOffset; },   // bez pomiaru układu
          pisz: function (cel, dt) {
            yPokaz += (cel - yPokaz) * (1 - Math.exp(-dt / TAU));
            if (Math.abs(cel - yPokaz) < .5) yPokaz = cel;
            maluj(yPokaz);
            return yPokaz !== cel;
          }
        });
        poZmianie.push(przelicz);
        window.addEventListener('load', przelicz);
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(przelicz);
      }
    }
  }

  /* 6. Paralaksa. Element sunie wolniej niż strona o wartość z data-px (w pikselach).
     Liczone względem środka ekranu, więc w punkcie zerowym element stoi tam,
     gdzie postawił go layout — pozycja bez skryptu jest zawsze poprawna. */
  var pxNodes = [].slice.call(document.querySelectorAll('[data-px]')).map(function (el) {
    return { el: el, ile: parseFloat(el.getAttribute('data-px')) || 0, y: 0 };
  });

  if (pxNodes.length && !reduced) {
    dodajZadanie({
      czytaj: function () {
        var vh = wysokosc();
        return pxNodes.map(function (n) {
          var r = n.el.getBoundingClientRect();
          var top = r.top - n.y;                             // pozycja bez własnego przesunięcia
          if (r.bottom - n.y < -vh || top > vh * 2) return null;   // poza zasięgiem: nie liczymy
          return (top + r.height / 2 - vh / 2) / vh * n.ile;       // -1 nad ekranem, +1 pod
        });
      },
      // Transformacja wprost w stylu elementu, nie przez zmienną CSS: zmienna dziedziczy się
      // w dół i przeglądarka przeliczała styl całego poddrzewa w każdej klatce.
      pisz: function (ys) {
        pxNodes.forEach(function (n, i) {
          if (ys[i] === null || Math.abs(ys[i] - n.y) < .05) return;
          n.y = ys[i];
          n.el.style.transform = 'translate3d(0,' + n.y.toFixed(1) + 'px,0)';
        });
      }
    });
  }

  /* 6a. Głębia między sekcjami. Treść pola jedzie wolniej niż jego tło:
     przy wejściu dogania pole od dołu, przy wyjściu zostaje w tyle i gaśnie. Przesuwamy tylko .wrap,
     nigdy samą sekcję — tła, lepkie kadry (Obszary) i pomiary sceny oraz kurtyny zostają nietknięte.
     data-warstwa w markupie mówi, którą połowę ruchu dostaje pole: wejscie, wyjscie albo obie.
     Treść nigdy nie zjeżdża pod następne pole: przesunięcie nie przekracza wolnego miejsca
     pod treścią (dolny odstęp sekcji) minus zapas. Wcześniej zostawała w tyle o stałe 260 px
     i następne pole zasłaniało ostatnie wiersze, a w „O mnie” pół portretu.
     Poniżej 1100 px ruch jest mocniejszy, bo odstępy są mniejsze: treść wchodzi z większym
     opóźnieniem, a przy wyjściu dodatkowo maleje (do 92%) i gaśnie mocniej.
     Ograniczony ruch: nic się nie dzieje, układ jak bez skryptu. */
  var warstwy = [].slice.call(document.querySelectorAll('[data-warstwa]')).map(function (sec) {
    var jak = sec.getAttribute('data-warstwa');
    return { sec: sec, el: sec.querySelector('.wrap'), we: /wejscie/.test(jak), wy: /wyjscie/.test(jak), y: 0 };
  }).filter(function (w) { return w.el; });

  if (warstwy.length && !reduced && 'requestAnimationFrame' in window) {
    var mqGlebia = window.matchMedia('(min-width: 1100px)');
    var ZAPAS = 27;   // px — tyle światła zostaje między treścią a następnym polem (3 × moduł --x)

    var czytajGlebie = function () {
      var vh = wysokosc();
      var desk = mqGlebia.matches;
      var dWe = desk ? Math.min(vh * .12, 120) : Math.min(vh * .25, 200);   // opóźnienie treści przy wejściu pola
      var dWy = Math.min(vh * .28, 260);   // o tyle najwyżej zostaje w tyle, gdy pole znika u góry
      var skala = desk ? 0 : .08;          // o ile maleje przy wyjściu (tylko telefon)
      var gasn = desk ? .55 : .6;

      return warstwy.map(function (w) {
        var r = w.sec.getBoundingClientRect();
        // Poza ekranem z zapasem: stan spoczynku, bez drugiego pomiaru.
        if (r.bottom < -vh || r.top > vh * 2) return { y: 0, o: 1, s: 1 };
        // Dół treści bez obecnego przesunięcia = ile miejsca zostaje do dolnej krawędzi pola.
        var wolne = r.bottom - (w.el.getBoundingClientRect().bottom - w.y);
        var luz = Math.max(0, wolne - ZAPAS);
        var y = 0, o = 1, s = 1;
        if (w.we && r.top > 0) y += clamp01(r.top / vh) * dWe;
        if (w.wy && r.bottom < vh) {
          var e = clamp01(1 - r.bottom / vh);
          y += e * Math.min(dWy, luz);      // skalowane, nie ucinane — ruch zostaje płynny
          o = 1 - e * gasn;
          s = 1 - e * skala;
        }
        // Część pod dolną krawędzią ekranu i tak jest niewidoczna, więc przy wejściu wolno więcej.
        y = Math.min(y, luz + Math.max(0, r.bottom - vh));
        return { y: y, o: o, s: s };
      });
    };

    // Transformacja i krycie wprost w stylu .wrap — zmienne CSS dziedziczyły się na całą treść sekcji
    // i przeglądarka przeliczała jej styl w każdej klatce. Zapis tylko przy realnej zmianie.
    var piszGlebie = function (wyniki) {
      warstwy.forEach(function (w, i) {
        var v = wyniki[i];
        var klucz = v.y.toFixed(1) + '|' + v.s.toFixed(4) + '|' + v.o.toFixed(3);
        if (klucz === w.klucz) return;
        w.klucz = klucz;
        w.y = v.y;
        w.el.style.transform = 'translate3d(0,' + v.y.toFixed(1) + 'px,0)' + (v.s < 1 ? ' scale(' + v.s.toFixed(4) + ')' : '');
        w.el.style.opacity = v.o < 1 ? v.o.toFixed(3) : '';
      });
    };

    // Klasy raz, przy starcie: głębia działa na każdej szerokości (proporcje liczy czytajGlebie).
    document.documentElement.classList.add('glebia');
    warstwy.forEach(function (w) { w.el.classList.add('warstwa'); });
    dodajZadanie({ czytaj: czytajGlebie, pisz: piszGlebie });
    if (mqGlebia.addEventListener) mqGlebia.addEventListener('change', budz);
    else if (mqGlebia.addListener) mqGlebia.addListener(budz);
  }

  /* 7. Kurtyna i pasek. Hero przypięte, „Punkt wyjścia” najeżdża na nie od dołu.
     --hero-top: przy hero wyższym niż okno (niski telefon) hero najpierw przewija się
     do końca i dopiero wtedy staje — inaczej dół wejścia byłby nie do zobaczenia.
     --cover (0–1): jak daleko zasłona weszła na ekran. Pasek z logo pojawia się,
     gdy zasłona dojdzie do góry okna. */
  var kurtyna = document.querySelector('[data-kurtyna]');
  var hero = document.querySelector('.hero');
  var punkt = document.querySelector('.punkt');
  var bar = document.querySelector('.sticky');

  if (kurtyna && hero && punkt) {
    var kurtynaLive = !reduced;
    kurtyna.classList.toggle('is-live', kurtynaLive);
    var ostatnieK = '';

    dodajZadanie({
      czytaj: function () {
        return { pTop: punkt.getBoundingClientRect().top, heroH: hero.offsetHeight };
      },
      pisz: function (m) {
        var vh = wysokosc();
        if (kurtynaLive) {
          var klucz = Math.min(0, vh - m.heroH) + 'px|' + clamp01(1 - m.pTop / vh).toFixed(4);
          if (klucz !== ostatnieK) {        // na dole strony zasłona stoi — nie przeliczamy stylu hero
            ostatnieK = klucz;
            var k = klucz.split('|');
            hero.style.setProperty('--hero-top', k[0]);
            hero.style.setProperty('--cover', k[1]);
          }
        }
        if (bar) bar.classList.toggle('is-on', m.pTop <= 1);
      }
    });
  } else if (bar && hero && hasIO) {
    new IntersectionObserver(function (entries) {
      bar.classList.toggle('is-on', !entries[0].isIntersecting);
    }, { threshold: 0 }).observe(hero);
  }

  /* 7a. Teza spod belek. Tekst dzielony na słowa (każde razem ze spacją za nim, więc belki
     łączą się w ciągły pas). Słowa przed czołem są jawne, 7 kolejnych stoi pod belką,
     reszta czeka niewidoczna. Odsłanianie rusza samo, gdy góra akapitu minie 60% wysokości ekranu,
     i trwa ok. 1,4 s — nie zależy od dalszego przewijania (wcześniej czoło szło za pozycją
     i kto zatrzymał się w pół drogi, widział pół zdania pod belkami).
     Start przy 60%, nie przy 30% widoczności akapitu: sekcja wjeżdża kurtyną na hero, więc przy 30%
     tekst był jeszcze przy dolnej krawędzi i animacja kończyła się, zanim wzrok tam doszedł.
     Przy ograniczonym ruchu i bez skryptu tekst stoi w całości. */
  var redact = document.querySelector('[data-redact]');

  if (redact && !reduced && hasIO && 'requestAnimationFrame' in window) {
    var slowa = [];
    var tnij = function (node) {
      [].slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 3) {
          var frag = document.createDocumentFragment();
          (n.nodeValue.match(/\S+\s*|\s+/g) || []).forEach(function (t) {
            if (!/\S/.test(t)) { frag.appendChild(document.createTextNode(t)); return; }
            var s = document.createElement('span');
            s.className = 'slowo';
            s.textContent = t;
            slowa.push(s);
            frag.appendChild(s);
          });
          node.replaceChild(frag, n);
        } else if (n.nodeType === 1) {
          tnij(n);
        }
      });
    };
    tnij(redact);

    var FALA = 7, CZAS_R = 1400;
    var czolo = -1;
    redact.classList.add('is-redact');

    var rysuj = function (nowe) {
      if (nowe === czolo) return;
      czolo = nowe;
      slowa.forEach(function (s, i) {
        var jawne = i < czolo - FALA;
        s.classList.toggle('is-jawne', jawne);
        s.classList.toggle('is-blok', !jawne && i < czolo);
      });
    };

    var koniecR = slowa.length + FALA;
    var startR = 0;
    var krokR = function (t) {
      if (!startR) startR = t;
      var p = clamp01((t - startR) / CZAS_R);
      rysuj(Math.round(p * koniecR));
      if (p < 1) window.requestAnimationFrame(krokR);
    };

    rysuj(0);
    var redactIO = new IntersectionObserver(function (entries) {
      if (!entries[0].isIntersecting) return;
      redactIO.disconnect();
      window.requestAnimationFrame(krokR);
    }, { rootMargin: '0px 0px -40% 0px', threshold: 0 });
    redactIO.observe(redact);
  }

  /* 8. Forma w hero: kropka ze znaku, która się rozlewa. Siedem punktów na okręgu,
     każdy z własnym oddechem promienia; przez punkty idzie gładka krzywa
     (Catmull-Rom → Bézier). Całość się obraca. Pętla działa tylko wtedy,
     gdy hero jest na ekranie. Przy ograniczonym ruchu zostaje kształt z markupu.
     Poprzednie tempo (fale 12 s i 7 s, wychylenie ±14%, obrót 2 min) było niewidoczne —
     wyglądało na nieruchomą kropkę. Teraz fale 5 s i 3,3 s, wychylenie ±22%, obrót 40 s.
     Promień bazowy zmniejszony do 150, żeby największe wybrzuszenie (≈183) nie wyszło
     poza dotychczasowy obrys (≈180) i nie weszło na tekst. */
  var blob = document.querySelector('[data-blob]');

  if (blob && !reduced && 'requestAnimationFrame' in window) {
    var P = 7, R = 150, CX = 200, CY = 200;
    // Strojenie: TEMPO mnoży prędkość wszystkich ruchów, AMP — siłę wybrzuszeń.
    var TEMPO = 1, AMP = 1;
    var blobOn = true, blobRaf = 0;

    var ksztalt = function (t) {
      t *= TEMPO;
      var pts = [], rot = t * .00016;
      for (var i = 0; i < P; i++) {
        var a = i / P * Math.PI * 2 + rot;
        var r = R * (1 + AMP * (.14 * Math.sin(t * .0012 + i * 2.1) + .08 * Math.sin(t * .0019 + i * 1.3 + 1.7)));
        pts.push([CX + Math.cos(a) * r, CY + Math.sin(a) * r]);
      }
      var d = 'M' + pts[0][0].toFixed(1) + ' ' + pts[0][1].toFixed(1);
      for (var k = 0; k < P; k++) {
        var p0 = pts[(k - 1 + P) % P], p1 = pts[k], p2 = pts[(k + 1) % P], p3 = pts[(k + 2) % P];
        d += 'C' + (p1[0] + (p2[0] - p0[0]) / 6).toFixed(1) + ' ' + (p1[1] + (p2[1] - p0[1]) / 6).toFixed(1) +
             ' ' + (p2[0] - (p3[0] - p1[0]) / 6).toFixed(1) + ' ' + (p2[1] - (p3[1] - p1[1]) / 6).toFixed(1) +
             ' ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
      }
      return d + 'Z';
    };

    var krok = function (t) {
      blob.setAttribute('d', ksztalt(t));
      blobRaf = blobOn ? window.requestAnimationFrame(krok) : 0;
    };

    blobRaf = window.requestAnimationFrame(krok);

    if (hasIO) {
      new IntersectionObserver(function (entries) {
        blobOn = entries[0].isIntersecting;
        if (blobOn && !blobRaf) blobRaf = window.requestAnimationFrame(krok);
      }, { threshold: 0 }).observe(blob.closest('svg'));
    }
  }

  /* 9. Rok w nocie prawnej — żeby nie zestarzał się bez powodu. */
  var year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();

  /* 10. Intro z logo. Klasę html.intro stawia skrypt w <head> (raz na kartę, bez kotwicy,
     bez ograniczonego ruchu). Pozycję końcową bierzemy ze znaku w hero, więc intro kończy się
     dokładnie tam, gdzie stoi prawdziwy znak — przejście jest niewidoczne.
     Kółko, dotyk, klawisz lub klik przerywają intro od razu: nikt nie czeka, jeśli nie chce. */
  var introRoot = document.documentElement;
  var znakHero = document.querySelector('.hero .bis-logo svg');

  if (introRoot.classList.contains('intro')) {
    var zakonczono = false, introEl = null, timery = [];

    var zakoncz = function (odRazu) {
      if (zakonczono) return;
      zakonczono = true;
      timery.forEach(clearTimeout);
      ['wheel', 'touchstart', 'keydown', 'pointerdown'].forEach(function (t) {
        window.removeEventListener(t, przerwij);
      });
      introRoot.classList.add('intro-gotowe');
      introRoot.classList.remove('intro');           // animacje hero ruszają spod planszy
      if (!introEl) return;
      if (odRazu) { introEl.remove(); return; }
      introEl.classList.add('is-koniec');
      setTimeout(function () { if (introEl) introEl.remove(); }, 400);
    };
    var przerwij = function () { zakoncz(true); };

    try { sessionStorage.setItem('bis-intro', '1'); } catch (e) {}

    if (!znakHero || reduced) {
      zakoncz(true);
    } else {
      var cel = znakHero.getBoundingClientRect();
      var vw = window.innerWidth, vhI = window.innerHeight;
      var g = Math.min(64, Math.max(20, vw * .05));              // ten sam margines co --gutter
      var s = Math.min((vw - 2 * g) / cel.width, vhI * .42 / cel.height);  // znak na całą szerokość, max 42% wysokości
      var dx = g - cel.left;
      var dy = (vhI - g * .7 - cel.height * s) - cel.top;          // dociśnięty do dołu ekranu

      introEl = document.createElement('div');
      introEl.className = 'intro-ekran';   // nie 'intro' — ta nazwa należy do znacznika na <html>
      introEl.setAttribute('aria-hidden', 'true');
      introEl.innerHTML = '<div class="intro-panel"></div><div class="intro-logo"></div>';
      var logoBox = introEl.querySelector('.intro-logo');
      logoBox.appendChild(znakHero.cloneNode(true));
      logoBox.style.left = cel.left + 'px';
      logoBox.style.top = cel.top + 'px';
      logoBox.style.width = cel.width + 'px';
      logoBox.style.height = cel.height + 'px';
      logoBox.style.transform = 'translate3d(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px,0) scale(' + s.toFixed(4) + ')';

      document.body.appendChild(introEl);
      introRoot.classList.add('intro-gotowe');       // zasłona z CSS schodzi, plansza już stoi

      ['wheel', 'touchstart', 'keydown', 'pointerdown'].forEach(function (t) {
        window.addEventListener(t, przerwij, { passive: true });
      });

      // Dwie klatki: przeglądarka musi najpierw narysować stan startowy, inaczej przejście nie ruszy.
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () { introEl.classList.add('is-1'); });
      });
      timery.push(setTimeout(function () { introEl.classList.add('is-2'); }, 1100));
      timery.push(setTimeout(function () { zakoncz(false); }, 2300));
    }
  }
})();
